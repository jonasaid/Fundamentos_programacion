#ifndef MATRIZ_H
#define MATRIZ_H

int num_aleatorio(int num);
void dos(matriz *m);
void tres(matriz *m);
void cuatro(matriz *m);
void cinco(matriz *m);
void seis(matriz *m, int renglon, int columna);
void siete(matriz *m, int renglon1, int columna1, int renglon2, int columna2);
void ocho(matriz *m, int renglon, int columna) ;
void nueve(matriz *m);
void diez(matriz *m, int renglon, int columna);

#endif